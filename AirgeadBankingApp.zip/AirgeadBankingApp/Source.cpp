// AirgeadBankingApp Ryan Miller

#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>
#include "BankCalculator.h"

using namespace std;

// function to chack valid input for initial_amount, monthly_deposit, and annual_interest
double CheckIfValid(string input) {
    double output;

    // while loop to continue recieveing input until valid
    while (true) {

        // if statement to chack for and remove $ and % prefixes
        if (input[0] == '$' || input[0] == '%') {
            input.erase(0, 1);  // remove the dollar sign
        }

        // try-catch to handle invalid input
        try {
            output = stod(input); // string to double

            // if-else to make sure value is positive
            if (output >= 0) {
                break;
            }
            else {
                throw runtime_error("Years must be greater than 0");
            }
        }
        catch (const exception&) {

            // gets new input if input is invalid
            cout << "Invalid input. Please enter a valid number: ";
            getline(cin, input);
        }
    }
    return output; // returns valid entry
} //end CheckIfValid

int main() {

    // while loop to allow user to enter new values
    while (true) {

        // initializes input variables
        double initialAmount, monthlyDeposit, annualInterest;
        int years;
        string input;

        // output formatting and initialAmount prompt
        cout << string(30, '*')
            << "\n\tData Input\n" 
            << string(30, '*')
            << "\nInitial Investment Amount: ";
        getline(cin, input);
        // check validity of input
        initialAmount = CheckIfValid(input);


        // monthlyDeposit prompt
        cout << "Monthly Deposit: ";
        getline(cin, input);
        // check validity of input
        monthlyDeposit = CheckIfValid(input);


        // annualInterest prompt
        cout << "Annual Interest: ";
        getline(cin, input);
        // check validity of input
        annualInterest = CheckIfValid(input);


        // years prompt
        cout << "Years: ";

        // while loop to continue recieveing input until valid
        while (true) {
            getline(cin, input);

            // try-catch to handle invalid input
            try {
                years = stoi(input); // string to int

                // if-else to make sure value is greater than 0
                if (years > 0) {
                    break;
                }
                else {
                    throw runtime_error("Years must be greater than 0");
                }
            }
            catch (const exception&) {

                // gets new input if input is invalid
                cout << "Invalid input. Please enter a valid integer: ";
            }
        }

        cout << "Press any key to continue\n";
        cin.ignore(); // ignore any previous input

        // creates BankCalculator object Account
        auto Account = make_unique<BankCalculator>(initialAmount, monthlyDeposit, annualInterest, years);

        // makes method calls to calculate and print relevant data for user input
        Account->BalanceWithoutMonthlyDeposit();
        Account->BalanceWithMonthlyDeposit();

        // prompt to continue or exit
        cout << "Would you like to input new values? (y/n): ";
        getline(cin, input);

        // continues on y or Y,
        if (input == "y" || input == "Y") {
            continue;
        }

        // any other value closes
        else {
            break;
        }
    }
    return 0;
} // end main