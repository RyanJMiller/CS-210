// AirgeadBankingApp Ryan Miller

#include <iostream>
#include <iomanip>
#include "BankCalculator.h"

using namespace std;

// default constructor
BankCalculator::BankCalculator() 
	: m_initialInvestment(0), m_monthlyDeposit(0), m_annualInterest(0), m_years(0)
{
}

// constructor with parameters
BankCalculator::BankCalculator(double t_initialInvestment, double t_monthlyDeposit, double t_annualInterest, int t_years)
	: m_initialInvestment(t_initialInvestment), m_monthlyDeposit(t_monthlyDeposit), m_annualInterest(t_annualInterest), m_years(t_years)
{
}


// sets initial investment
void BankCalculator::SetInitialInvestment(double t_initialInvestment) {
    m_initialInvestment = t_initialInvestment;
}

// sets monthly deposit
void BankCalculator::SetMonthlyDeposit(double t_monthlyDeposit) {
    m_monthlyDeposit = t_monthlyDeposit;
}

// sets annual interest rate
void BankCalculator::SetAnnualInterest(double t_annualInterest) {
    m_annualInterest = t_annualInterest;
}

// sets number of years
void BankCalculator::SetYears(int t_years) {
    m_years = t_years;
}


// returns initial investment
double BankCalculator::GetInitialInvestment() {
    return m_initialInvestment;
}

// returns monthly deposit
double BankCalculator::GetMonthlyDeposit() {
    return m_monthlyDeposit;
}

// returns annual interest rate
double BankCalculator::GetAnnualInterest() {
    return m_annualInterest;
}

// returns number of years
int BankCalculator::GetYears() {
    return m_years;
}


// prints a line of output data
void BankCalculator::PrintDetails(int year, double yearEndBalance, double interestEarned) {
    cout << setw(3) << year << "\t";
    cout << fixed << setprecision(2) << setw(12) << "$" << yearEndBalance << "\t";
    cout << fixed << setprecision(2) << setw(18) << "$" << interestEarned << endl << endl;
}

// calculates balance without monthly deposit
double BankCalculator::BalanceWithoutMonthlyDeposit() {

    // initializes variables for balance/interest calculation via get functions
    double bal = GetInitialInvestment();
    double monthlyInterestRate = GetAnnualInterest() / 100 / 12;
    int numYears = GetYears();
    double interestEarnedThisYear = 0.0;

    // output formatting for the balance table
    cout << setw(3) << "Balance and Interest Without Additional Monthly Deposits" << endl;
    cout << string(58, '*') << endl;
    cout << "Year\t" << setw(5) << "Year End Balance\t" << setw(5) << "Year End Earned Interest" << endl;
    cout << string(58, '-') << endl;

    /*
    * loops through each year for the number of years given
    * calculating interest, and adding it to the balance
    * before sending both values and the year to PrintDetails
    */
    for (int year = 1; year <= numYears; year++) {
        interestEarnedThisYear = 0.0;

        interestEarnedThisYear = bal * monthlyInterestRate * 12;
        bal += interestEarnedThisYear;

        PrintDetails(year, bal, interestEarnedThisYear);
    }

    cout << endl; // newline
    return bal;
}

// calculates balance with monthly deposit
double BankCalculator::BalanceWithMonthlyDeposit() {

    // initializes variables for balance/interest calculation via get functions
    double bal = GetInitialInvestment();
    double monthlyDeposit = GetMonthlyDeposit();
    double monthlyInterestRate = GetAnnualInterest() / 100 / 12;
    int numYears = GetYears();
    double interestEarnedThisYear = 0.0;
    double monthlyInterestEarned = 0.0;

    // output formatting for the balance table
    cout << setw(3) << "Balance and Interest With Additional Monthly Deposits" << endl;
    cout << string(58, '*') << endl;
    cout << "Year\t" << setw(5) << "Year End Balance\t" << setw(5) << "Year End Earned Interest" << endl;
    cout << string(58, '-') << endl;

    
    // loops through each year for the number of years given.
    for (int year = 1; year <= numYears; year++) {
        interestEarnedThisYear = 0.0;

        /*
        * for each year, loops through 12 months calculating
        * monthly interest and adding it to interest earned
        * this year. monthly deposit and monthly interest
        * earned to balance
        */
        for (int month = 1; month <= 12; month++) {
            monthlyInterestEarned = (bal + monthlyDeposit) * monthlyInterestRate;
            interestEarnedThisYear += monthlyInterestEarned;
            bal += monthlyDeposit;
            bal += monthlyInterestEarned;
        }

        // sends year, balance, and interest earned for each year to PrintDetails
        PrintDetails(year, bal, interestEarnedThisYear);
    }

    cout << endl;
    return bal;
}