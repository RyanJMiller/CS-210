// AirgeadBankingApp Ryan Miller

#ifndef BANK_CALCULATOR_H
#define BANK_CALCULATOR_H

using namespace std;

// class to hold data for each user entry and house the necessary functions
class BankCalculator {

// private member vars
private:
    double m_initialInvestment;
    double m_monthlyDeposit;
    double m_annualInterest;
    int m_years;

// public member functions
public:
    BankCalculator();
    BankCalculator(double t_initialInvestment, double t_monthlyDeposit, double t_annualInterest, int t_years);

    // set functions
    void SetInitialInvestment(double t_initialInvestment);
    void SetMonthlyDeposit(double t_monthlyDeposit);
    void SetAnnualInterest(double t_annualInterest);
    void SetYears(int t_years);

    // get functions
    double GetInitialInvestment();
    double GetMonthlyDeposit();
    double GetAnnualInterest();
    int GetYears();

    // calculation and output functions
    void PrintDetails(int year, double yearEndBalance, double interestEarned);
    double BalanceWithoutMonthlyDeposit();
    double BalanceWithMonthlyDeposit();
};

#endif